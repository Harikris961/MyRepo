# PlacePrep: Career Readiness Portal

A single-file, no-backend web app with three role-based portals: **Student**, **Faculty** and **Administrator**. All data is stored in the browser's `localStorage`.

## Features

**Student:** profile, academics (SGPA grid), subject marks (manual and CSV upload), certificates, skills with evidence, resume upload, placement readiness score, charts, skill-gap analysis, faculty feedback and action items, placement drives with eligibility checks, JSON export/import, and analytics (role skills radar, readiness trend, peer benchmark, what-if readiness simulator, CGPA projection).

**Faculty:** mentee overview, readiness insights, searchable and sortable roster with CSV export, student detail drawer with notes and action items, and analytics (grades vs readiness scatter, placement funnel, skill coverage heatmap, mentee progress heatmap, action-item completion).

**Administrator:** institution overview, department performance, placement status and readiness trend, skill supply vs employer demand, drive management, mentor assignment, and account management.

## Run locally

No build step. Open `index.html` in any modern browser.

## Deploy with GitHub Pages

1. Create a new repository on GitHub and upload `index.html`, `README.md` and `.nojekyll`.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
4. After a minute your site is live at `https://<your-username>.github.io/<repository-name>/`.

## Demo accounts

Click a demo account on the login screen to fill in its credentials.

## Important limitations

- This is a **prototype**. Authentication is client-side only and passwords are stored in plain text in `localStorage`. Do not use it with real student data.
- Data is stored per browser and device, so different users do not see each other's changes unless they use the same browser.
- Uploaded files are limited to about 1 MB, and the browser's `localStorage` quota limits total stored data.

## Tech

Plain HTML, CSS and JavaScript with hand-built SVG charts. No frameworks or dependencies.
